package com.devshiv.quotesflutter.quotes_app_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
